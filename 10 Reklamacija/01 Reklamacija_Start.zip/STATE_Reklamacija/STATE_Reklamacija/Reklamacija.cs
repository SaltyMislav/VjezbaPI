﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_Reklamacija
{
    public class Reklamacija
    {
        public int Id { get; set; }
        public string Opis { get; set; }

        public string Agent { get; private set; }

        public Reklamacija()
        {

        }

        public void DodijeliAgenta(string agent)
        {
            Agent = agent;
        }

        public void Prihvati()
        {
            PosaljiObavijest("Vaša reklamacija je uvažena.");
        }

        private void PosaljiObavijest(string poruka)
        {
            //Šalje mail korisniku... NE TREBA IMPLEMENTIRATI
        }

        public void Odbij()
        {
            PosaljiObavijest("Vaša reklamacija je odbijena. Imate 3 dana za žalbu na tu odluku.");
        }

        public void KonačnoOdbij()
        {
            PosaljiObavijest("Vaša reklamacija je konačno odbijena. Više nemate mogućnost žalbe.");
        }

        public void VratiUPostupak()
        {

        }
    }
}
