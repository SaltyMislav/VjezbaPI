﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_Oven
{
    enum ProgramRada
    {
        Pečenje_150C,
        Pečenje_180C,
        Pečenje_200C
    }
}
