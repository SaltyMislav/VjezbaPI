﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_Oven
{
    class Pecnica
    {
        public string NazivPecnice { get; set; }
        public ProgramRada Program { get; set; }

        public Pecnica()
        {
            NazivPecnice = "Electrolux 14232";
        }

        public void Upali()
        {

        }

        public void Ugasi()
        {

        }

        public void OdaberiProgram(ProgramRada program)
        {
            Program = program;

        }

        public void ZapocniPecenje()
        {

        }

        public void OznaciKaoZavrseno()
        {

        }

        public void OhladiPecnicu()
        {

        }
    }
}
