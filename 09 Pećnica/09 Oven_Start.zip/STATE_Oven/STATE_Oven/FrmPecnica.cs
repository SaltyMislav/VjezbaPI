﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STATE_Oven
{
    public partial class FrmPecnica : Form
    {
        Pecnica pecnica = new Pecnica();
        public FrmPecnica()
        {
            InitializeComponent();
        }

        private void FrmPerilica_Load(object sender, EventArgs e)
        {

        }



        private void btnOnOff_Click(object sender, EventArgs e)
        {

        }

        private void btn150C_Click(object sender, EventArgs e)
        {

        }

        private void btn180C_Click(object sender, EventArgs e)
        {

        }

        private void btn200C_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {

        }

        private void btnIstekloVrijeme_Click(object sender, EventArgs e)
        {

        }

        private void btnOhladiPecnicu_Click(object sender, EventArgs e)
        {

        }
    }
}
