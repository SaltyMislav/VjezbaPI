﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_ServisniZahtjev
{
    public class ServisniZahtjev
    {
        public string Opis { get; set; }
        public DateTime DatumIzrade { get; set; }
        public DateTime DatumZaprimanja { get; set; }
        public DateTime DatumPocetka { get; set; }
        public DateTime DatumZatvaranja { get; set; }
        public DateTime DatumOdbijanja { get; set; }

        public void PodnesiZahtjev(string opis, DateTime datumIzrade)
        {
            Opis = opis;
            DatumIzrade = datumIzrade;
        }

        public void ZaprimiZahtjev(DateTime datumZaprimanja)
        {
            DatumZaprimanja = DateTime.Now;
        }

        public void ZapocniServisiranje(DateTime datumPocetka)
        {
            DatumPocetka = datumPocetka;
        }

        internal void ZatvoriZahtjev(DateTime datumDovrsetka)
        {
            DatumZatvaranja = datumDovrsetka;
        }

        public void OdbijZahtjev()
        {
            DatumOdbijanja = DateTime.Now;
        }
    }
}
