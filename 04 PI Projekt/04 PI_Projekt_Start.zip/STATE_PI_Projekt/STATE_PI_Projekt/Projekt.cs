﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_PI_Projekt
{
    public class Projekt
    {
        public string OpisTeme { get; set; }
        public string OznakaTima { get; set; }
        public DateTime DatumPredaje { get; set; }
        public DateTime DatumObrane { get; set; }

        public Projekt()
        {

        }

        public void ZabiljeziTemu(string opisTeme, string oznakaTima)
        {
            OpisTeme = opisTeme;
            OznakaTima = oznakaTima;
        }

        public void PredajProjekt(DateTime datumPredaje)
        {
            DatumPredaje = datumPredaje;
        }

        public void OdbijProjekt()
        {
        }

        public void PrihvatiProjekt()
        {
        }

        public void ZakažiObranu(DateTime datumObrane)
        {
            DatumObrane = datumObrane;
        }

        public void OznačiKaoObranjen()
        {
        }
    }
}
