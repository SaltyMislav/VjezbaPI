﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STATE_PI_Projekt
{
    public partial class FrmProjekt : Form
    {
        private Projekt _projekt;
        public FrmProjekt()
        {
            InitializeComponent();
        }

        private void FrmProjekt_Load(object sender, EventArgs e)
        {
            _projekt = new Projekt();
        }

        private void btnZabiljeziTemu_Click(object sender, EventArgs e)
        {
            _projekt.ZabiljeziTemu(txtOpisProjekta.Text, txtOznakaTima.Text);
        }

        private void btnPredajProjekt_Click(object sender, EventArgs e)
        {
            _projekt.PredajProjekt(dtpDatumPredaje.Value);
        }

        private void btnOdbijProjekt_Click(object sender, EventArgs e)
        {
            _projekt.OdbijProjekt();
        }

        private void btnPrihvatiProjekt_Click(object sender, EventArgs e)
        {
            _projekt.PrihvatiProjekt();
        }

        private void btnZakaziObranu_Click(object sender, EventArgs e)
        {
            _projekt.ZakažiObranu(dtpDatumObrane.Value);
        }

        private void btnOznaciKaoObranjen_Click(object sender, EventArgs e)
        {
            _projekt.OznačiKaoObranjen();
        }
    }
}
