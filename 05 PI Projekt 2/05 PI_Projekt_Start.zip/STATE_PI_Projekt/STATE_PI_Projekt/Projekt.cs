﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_PI_Projekt
{
    public class Projekt
    {
        public string OpisTeme { get; set; }
        public string OznakaTima { get; set; }
        public DateTime DatumPredajePrveFaze { get; set; }
        public DateTime DatumPredajeCijelogProjekta { get; set; }
        public int BrojBodova { get; set; }

        public Projekt()
        {

        }

        public void ZabiljeziTemu(string opisTeme, string oznakaTima)
        {
            OpisTeme = opisTeme;
            OznakaTima = oznakaTima;
        }

        public void PredajPrvuFazu(DateTime datumPredaje)
        {
            DatumPredajePrveFaze = datumPredaje;
        }

        public void OdbijTemu()
        {
        }

        public void PrihvatiTemu()
        {
        }

        public void PredajCijeliProjekt(DateTime datumObrane)
        {
            DatumPredajeCijelogProjekta = datumObrane;
        }

        public void OcijeniProjekt(int brojBodova)
        {
            BrojBodova = brojBodova;
        }
    }
}
