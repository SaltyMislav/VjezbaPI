﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STATE_PI_Projekt
{
    public partial class FrmProjekt : Form
    {
        private Projekt _projekt;
        public FrmProjekt()
        {
            InitializeComponent();
        }

        private void FrmProjekt_Load(object sender, EventArgs e)
        {
            _projekt = new Projekt();
        }

        private void btnZabiljeziTemu_Click(object sender, EventArgs e)
        {
            _projekt.ZabiljeziTemu(txtOpisTeme.Text, txtOznakaTima.Text);
        }

        private void btnPredajPrvuFazu_Click(object sender, EventArgs e)
        {
            _projekt.PredajPrvuFazu(dtpDatumPrveFaze.Value);
        }

        private void btnOdbijTemu_Click(object sender, EventArgs e)
        {
            _projekt.OdbijTemu();
        }

        private void btnPrihvatiTemu_Click(object sender, EventArgs e)
        {
            _projekt.PrihvatiTemu();
        }

        private void btnPredajCijeliProjekt_Click(object sender, EventArgs e)
        {
            _projekt.PredajCijeliProjekt(dtpDatumPredajeCijelogProjekta.Value);
        }

        private void btnOcijeni_Click(object sender, EventArgs e)
        {
            _projekt.OcijeniProjekt(int.Parse(txtBrojBodova.Text));
        }
    }
}
