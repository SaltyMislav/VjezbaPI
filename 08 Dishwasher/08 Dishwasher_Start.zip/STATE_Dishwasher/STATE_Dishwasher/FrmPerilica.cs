﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STATE_Dishwasher
{
    public partial class FrmPerilica : Form
    {
        Perilica perilica = new Perilica();
        public FrmPerilica()
        {
            InitializeComponent();
        }

        private void FrmPerilica_Load(object sender, EventArgs e)
        {

        }

        private void btnOnOff_Click(object sender, EventArgs e)
        {

        }

        private void btn60min_Click(object sender, EventArgs e)
        {

        }

        private void btn90min_Click(object sender, EventArgs e)
        {

        }

        private void btn120min_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {

        }

        private void btnPauzirajNastavi_Click(object sender, EventArgs e)
        {

        }

        private void btnPranjeZavrsilo_Click(object sender, EventArgs e)
        {

        }
    }
}
