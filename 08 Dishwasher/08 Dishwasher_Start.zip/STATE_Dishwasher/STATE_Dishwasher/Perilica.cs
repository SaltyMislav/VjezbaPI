﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_Dishwasher
{
    class Perilica
    {
        public string NazivPerilice { get; set; }
        public ProgramRada Program { get; set; }


        public Perilica()
        {
            NazivPerilice = "BOSCH GDS3429";
        }

        public void Upali()
        {
        }

        public void Ugasi()
        {
        }

        public void OdaberiProgram(ProgramRada odabraniProgram)
        {
            Program = odabraniProgram;
        }

        public void ZapocniPranje()
        {
        }

        public void OznaciPranjeZavrsilo()
        {
        }

        public void PauzirajPranje()
        {

        }

        public void NastaviPranje()
        {

        }
    }
}
