﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STATE_Dishwasher
{
    enum ProgramRada
    {
        Pranje_60min,
        Pranje_90min,
        Pranje_120min
    }
}
